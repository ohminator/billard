
import sum.kern.*;

public class Kugel
{
    // Objekte
    Buntstift hatStift;
    int zRadius;
    int zMinH;
    int zMaxH;
    int zMinV;
    int zMaxV;
    double zGeschwindigkeit;

    // Konstruktor
    public Kugel(double pAnfangH, double pAnfangV, double pGeschwindigkeit, double pWinkel, int farbe)
    {
        hatStift = new Buntstift();
        hatStift.bewegeBis(pAnfangH,pAnfangV);
        hatStift.dreheBis(pWinkel);
        hatStift.setzeFuellMuster(1);
        hatStift.setzeFarbe(farbe);
        zRadius = 5;
        zMinH = 105;
        zMaxH = 595;
        zMinV = 105;
        zMaxV = 295;
        zGeschwindigkeit = pGeschwindigkeit;
    }

    // Dienste
    public void gibFrei()
    {
        hatStift.gibFrei();
    }
    
    public void zeichne()
    {
        hatStift.zeichneKreis(zRadius);
    }
    
    public void loesche()
    {
        hatStift.radiere();
        hatStift.zeichneKreis(zRadius);
        hatStift.normal();
    }
    
    public void setzeRichtung(int pWinkel)
    {
        hatStift.dreheUm(pWinkel);
    }
    
    public double richtung()
    {
        return hatStift.winkel();
    }
    
    public double hPosition()
    {
        return hatStift.hPosition();
    }
    
    public double vPosition()
    {
        return hatStift.vPosition();
    }
    
    public void beweg()
    {
        this.loesche();
        hatStift.bewegeUm(zGeschwindigkeit);
        this.zeichne();
        if (this.hPosition() > zMaxH || this.hPosition() < zMinH)
            hatStift.dreheBis(180-this.richtung());
        if (this.vPosition() > zMaxV || this.vPosition() < zMinV)
            hatStift.dreheBis(360-this.richtung());
    }
}