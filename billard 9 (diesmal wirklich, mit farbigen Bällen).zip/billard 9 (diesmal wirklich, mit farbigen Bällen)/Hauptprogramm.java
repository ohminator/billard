import sum.kern.*;
/**
 * @author 
 * @version 
 */
public class Hauptprogramm
{
    // Objekte
    Bildschirm derBildschirm;
    Kugel dieKugel;
    Kugel weitereKugel;
    Maus dieMaus;
    Stift hatStift;

    // Konstruktor
    public Hauptprogramm()
    {
        derBildschirm = new Bildschirm(700,700);
        dieKugel = new Kugel(130,200,0.5,330,5);
        weitereKugel = new Kugel(330,260,1,50,7);
        dieMaus = new Maus();
        hatStift = new Stift();
    }

    // Dienste
    public void fuehreAus()
    {
        hatStift.bewegeBis(100,100);
        dieKugel.gibFrei();
        weitereKugel.gibFrei();
        dieKugel.zeichne();
        weitereKugel.zeichne();
        do
        {
            hatStift.zeichneRechteck(500,200);
            dieKugel.beweg();
            weitereKugel.beweg();
        } while(!dieMaus.doppelKlick());
    }
}