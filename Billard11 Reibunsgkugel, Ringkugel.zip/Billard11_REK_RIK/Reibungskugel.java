
/**
 * Beschreiben Sie hier die Klasse Reibungskugel.
 * 
 * @author Jannis Cvijanovic 
 * @version 07.03.2025
 */
public class Reibungskugel extends Kugel
{
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen

    /**
     * Konstruktor für Objekte der Klasse Reibungskugel
     */
    public Reibungskugel(double pAnfangH, double pAnfangV, double pGeschwindigkeit, int pRichtung)
    {
        super(pAnfangH, pAnfangV, pGeschwindigkeit, pRichtung);
    }

    public void bewege()
    {
        zGeschwindigkeit = zGeschwindigkeit * 0.9999;
        super.bewege();
    }
}
