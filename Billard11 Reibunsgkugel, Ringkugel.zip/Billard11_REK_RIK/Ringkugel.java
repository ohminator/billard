
/**
 * Beschreiben Sie hier die Klasse Ringkugel.
 * 
 * @author Jannis Cvijanovic 
 * @version 07.03.2025
 */
public class Ringkugel extends Kugel
{
    
    //Attribute oder Zustandsvariablen
    double zRing;
    // Instanzvariablen - ersetzen Sie das folgende Beispiel mit Ihren Variablen

    /**
     * Konstruktor für Objekte der Klasse Ringkugel
     */
    public Ringkugel(double pAnfangH, double pAnfangV, double pGeschwindigkeit, int pRichtung, double pRing)
    {
        super(pAnfangH, pAnfangV, pGeschwindigkeit, pRichtung);
        zRing = pRing;
    }

    public void zeichne()
    {
        hatStift.zeichneKreis(zRadius);
        hatStift.zeichneKreis(zRadius + zRing);
        super.zeichne();
    }
}
