import sum.kern.*;
/**
 * @author 
 * @version 
 */
public class ReibungsKugel extends Kugel
{
    Bildschirm derBildschirm;
    Stift meinStift;
    public ReibungsKugel(double pAnfangH, double pAnfangV, double pGeschwindigkeit, int pRichtung)
    {
        super(pAnfangH, pAnfangV, pGeschwindigkeit, pRichtung);
    }

    public void bewege()
    {
        zGeschwindigkeit = zGeschwindigkeit*0.9999;
        super.bewege();
    }
}