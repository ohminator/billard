import sum.kern.*;

public class Kugel
{
    // Objektnamen
    Stift hatStift;
    Bildschirm kenntBildschirm;
    
    //Attribute oder Zustandsvariablen
    
    int zRadius;
    double zGeschwindigkeit;
    
    
    // Konstruktor
    public Kugel(double pAnfangH, double pAnfangV, double pGeschwindigkeit, int pRichtung)
    {
        zRadius=5;
        zGeschwindigkeit=pGeschwindigkeit;
        hatStift = new Stift();
        hatStift.bewegeBis(pAnfangH, pAnfangV);
        hatStift.dreheBis(pRichtung);
        
    }
    
    public void gibFrei()
    {
        hatStift.gibFrei();
    }
   public void merke(Bildschirm pBildschirm)
    {
        kenntBildschirm = pBildschirm;
    } 
    public void bewege()
    {
        this.loesche();
        hatStift.bewegeUm(zGeschwindigkeit);
        this.zeichne();
        if (this.hPosition() > kenntBildschirm.breite()) // am rechten Rand
            this.setzeRichtung((180 - this.richtung()));
        if (this.hPosition() < 0) // am linken Rand
                this.setzeRichtung(180 - this.richtung());
        if (this.vPosition() > kenntBildschirm.hoehe()) // am unteren Rand
                this.setzeRichtung(360 - this.richtung());
        if (this.vPosition() < 0) // am oberen Rand
                this.setzeRichtung(360 - this.richtung());        
    }
    
    public void zeichne()
    {
        hatStift.zeichneKreis(zRadius);
    }
    
    public void loesche()
    {
        hatStift.radiere();
        this.zeichne();
        hatStift.normal();
    }
    
    public double hPosition()
    {
        return hatStift.hPosition();
    }
    
    public double vPosition()
    {
        return hatStift.vPosition();
    }
    
    public void setzeRichtung(double pWinkel)
    {
        hatStift.dreheBis(pWinkel);
    }
    public double richtung()
    {
        return hatStift.winkel();
    }

}
