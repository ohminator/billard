import sum.kern.*;

public class Billard10
{
    Bildschirm derBildschirm;
    Maus dieMaus;
    Kugel meineKugel;
    Kugel  meineKugel2;
   
        
    public Billard10()
    {
        
        // Initialisierung
        derBildschirm = new Bildschirm(600,600);
        dieMaus = new Maus();
        meineKugel = new Kugel(20,50, 0.25, 75); //schnelle Kugel
        meineKugel.merke(derBildschirm);
        meineKugel2 = new Kugel(220,250, 0.05, 167); //langsame Kugel
        meineKugel2.merke(derBildschirm);

        
    }
    public void fuehreAus()
    {

       
        meineKugel.zeichne();
        meineKugel2.zeichne();
        do
        {
            meineKugel.bewege();
            meineKugel2.bewege();
        } while (!dieMaus.istGedrueckt());
        
        // Aufraeumen
       
        meineKugel.gibFrei();
        meineKugel2.gibFrei();
        dieMaus.gibFrei();
        derBildschirm.gibFrei();
    }
}
